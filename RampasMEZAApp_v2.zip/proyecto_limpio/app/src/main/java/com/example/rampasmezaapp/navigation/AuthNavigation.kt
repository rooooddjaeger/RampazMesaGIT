package com.example.rampasmezaapp.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.rampasmezaapp.ui.auth.LoginScreen
import com.example.rampasmezaapp.ui.auth.RegisterScreen
import com.example.rampasmezaapp.ui.inventario.PanelDeControl
import com.example.rampasmezaapp.ui.inventario.AnadirStock
import com.example.rampasmezaapp.ui.admin.PanelAdmin

@Composable
fun AuthNavigation(
    navController: NavHostController,
    authViewModel: com.example.rampasmezaapp.ui.auth.AuthViewModel,
    inventarioGlobalViewModel: com.example.rampasmezaapp.ui.inventario.ViewModelInventarioGlobal
) {
    val authState = authViewModel.authState.collectAsState().value

    // Navegar según rol cuando el usuario esté autenticado y el rol cargado
    LaunchedEffect(authState.user, authState.rol) {
        if (authState.user != null && authState.rol != null) {
            val destino = if (authState.rol == "admin") "panel_admin" else "inventory"
            navController.navigate(destino) {
                popUpTo("login") { inclusive = true }
            }
        }
    }

    NavHost(navController = navController, startDestination = "login") {

        composable("login") {
            LoginScreen(
                onLoginClick = { email, password -> authViewModel.login(email, password) },
                onRegisterClick = { navController.navigate("register") },
                isLoading = authState.isLoading,
                errorMessage = authState.errorMessage
            )
        }

        composable("register") {
            RegisterScreen(
                onRegisterClick = { email, name, password -> authViewModel.register(email, name, password) },
                onLoginClick = { navController.navigate("login") },
                isLoading = authState.isLoading,
                errorMessage = authState.errorMessage
            )
        }

        // ── PANEL EMPLEADO ─────────────────────────────────────────────
        composable("inventory") {
            PanelDeControl(
                esAdmin = false,
                nombreUsuario = authState.nombre ?: "",
                onLogoutClick = {
                    authViewModel.logout()
                    navController.navigate("login") { popUpTo("login") { inclusive = true } }
                },
                onAddStockClick = { navController.navigate("add_stock") },
                onRegistrarVentasClick = { navController.navigate("registrar_ventas") },
                onHistorialVentasClick = {},
                onReporteInventarioClick = {}
            )
        }

        // ── PANEL ADMIN ─────────────────────────────────────────────────
        composable("panel_admin") {
            PanelAdmin(
                nombreAdmin = authState.nombre ?: "Admin",
                inventarioGlobalViewModel = inventarioGlobalViewModel,
                onLogoutClick = {
                    authViewModel.logout()
                    navController.navigate("login") { popUpTo("login") { inclusive = true } }
                },
                onAddStockClick = { navController.navigate("add_stock") },
                onRegistrarVentasClick = { navController.navigate("registrar_ventas") },
                onHistorialVentasClick = { navController.navigate("historial_ventas") },
                onReporteInventarioClick = { navController.navigate("reporte_inventario") },
                onAdminUsuariosClick = { navController.navigate("admin_usuarios") },
                onEstadisticasClick = { navController.navigate("estadisticas") }
            )
        }

        composable("add_stock") {
            AnadirStock(
                inventarioGlobalViewModel = inventarioGlobalViewModel,
                onBackToMainClick = { navController.popBackStack() }
            )
        }

        composable("registrar_ventas") {
            com.example.rampasmezaapp.ui.ventas.RegistrarVentas(
                nombreEmpleado = authState.nombre ?: "Empleado",
                inventarioGlobalViewModel = inventarioGlobalViewModel,
                onBackToMainClick = { navController.popBackStack() }
            )
        }

        composable("historial_ventas") {
            com.example.rampasmezaapp.ui.ventas.HistorialVentas(
                onBackToMainClick = { navController.popBackStack() }
            )
        }

        composable("reporte_inventario") {
            com.example.rampasmezaapp.ui.inventario.ReporteInventario(
                inventarioGlobalViewModel = inventarioGlobalViewModel,
                onBackToMainClick = { navController.popBackStack() }
            )
        }

        composable("admin_usuarios") {
            com.example.rampasmezaapp.ui.admin.AdminUsuarios(
                onBackClick = { navController.popBackStack() }
            )
        }

        composable("estadisticas") {
            com.example.rampasmezaapp.ui.admin.EstadisticasScreen(
                inventarioGlobalViewModel = inventarioGlobalViewModel,
                onBackClick = { navController.popBackStack() }
            )
        }
    }
}
