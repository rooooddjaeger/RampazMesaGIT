package com.example.rampasmezaapp.ui.auth

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

data class AuthState(
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
    val user: FirebaseUser? = null,
    val rol: String? = null,
    val nombre: String? = null
)

class AuthViewModel : ViewModel() {
    private val auth = FirebaseAuth.getInstance()
    private val firestore = FirebaseFirestore.getInstance()

    private val _authState = MutableStateFlow(AuthState())
    val authState: StateFlow<AuthState> = _authState.asStateFlow()

    init {
        auth.addAuthStateListener { firebaseAuth ->
            val user = firebaseAuth.currentUser
            if (user != null) {
                _authState.value = _authState.value.copy(user = user)
                cargarRolUsuario(user.uid)
            } else {
                _authState.value = AuthState()
            }
        }
    }

    private fun cargarRolUsuario(uid: String) {
        viewModelScope.launch {
            try {
                val doc = firestore.collection("users").document(uid).get().await()
                val rol = doc.getString("rol") ?: "usuario"
                val nombre = doc.getString("name") ?: ""
                _authState.value = _authState.value.copy(rol = rol, nombre = nombre)
            } catch (e: Exception) {
                _authState.value = _authState.value.copy(rol = "usuario")
            }
        }
    }

    fun login(email: String, password: String) {
        viewModelScope.launch {
            _authState.value = _authState.value.copy(isLoading = true, errorMessage = null)
            try {
                auth.signInWithEmailAndPassword(email, password).await()
                _authState.value = _authState.value.copy(isLoading = false)
            } catch (e: Exception) {
                _authState.value = _authState.value.copy(isLoading = false, errorMessage = getErrorMessage(e))
            }
        }
    }

    fun register(email: String, name: String, password: String) {
        viewModelScope.launch {
            _authState.value = _authState.value.copy(isLoading = true, errorMessage = null)
            try {
                val result = auth.createUserWithEmailAndPassword(email, password).await()
                val user = result.user
                if (user != null) {
                    val userData = hashMapOf(
                        "name" to name,
                        "email" to email,
                        "rol" to "usuario",
                        "activo" to true,
                        "createdAt" to System.currentTimeMillis()
                    )
                    firestore.collection("users").document(user.uid).set(userData).await()
                }
                _authState.value = _authState.value.copy(isLoading = false)
            } catch (e: Exception) {
                _authState.value = _authState.value.copy(isLoading = false, errorMessage = getErrorMessage(e))
            }
        }
    }

    fun logout() {
        auth.signOut()
    }

    fun clearError() {
        _authState.value = _authState.value.copy(errorMessage = null)
    }

    private fun getErrorMessage(exception: Exception): String {
        return when {
            exception.message?.contains("badly formatted") == true -> "El formato del email no es válido"
            exception.message?.contains("INVALID_LOGIN_CREDENTIALS") == true -> "Las credenciales son incorrectas"
            exception.message?.contains("no user record") == true -> "No existe una cuenta con este email"
            exception.message?.contains("email address is already") == true -> "Este email ya está registrado"
            exception.message?.contains("password is invalid") == true -> "La contraseña debe tener al menos 6 caracteres"
            exception.message?.contains("network error") == true -> "Error de conexión. Verifica tu internet"
            else -> "Las credenciales son incorrectas o no existen"
        }
    }
}
