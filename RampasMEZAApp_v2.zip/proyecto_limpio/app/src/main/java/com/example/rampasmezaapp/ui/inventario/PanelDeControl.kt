package com.example.rampasmezaapp.ui.inventario

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.rampasmezaapp.R

private val Amarillo = Color(0xFFFFD700)
private val AmarilloOscuro = Color(0xFFF0C000)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PanelDeControl(
    esAdmin: Boolean,
    nombreUsuario: String,
    onLogoutClick: () -> Unit,
    onAddStockClick: () -> Unit,
    onRegistrarVentasClick: () -> Unit,
    onHistorialVentasClick: () -> Unit,
    onReporteInventarioClick: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Panel de Empleado", fontWeight = FontWeight.Bold, color = Color.Black, fontSize = 18.sp)
                        if (nombreUsuario.isNotBlank())
                            Text("Hola, $nombreUsuario", fontSize = 12.sp, color = Color.Gray)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White),
                actions = {
                    IconButton(onClick = onLogoutClick) {
                        Icon(Icons.AutoMirrored.Filled.ExitToApp, "Cerrar sesión", tint = Color.Black)
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.White)
                .padding(paddingValues)
                .padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(32.dp))
            Image(
                painter = painterResource(id = R.drawable.logo_rampas_meza),
                contentDescription = "Logo Rampas Meza",
                modifier = Modifier.size(160.dp).clip(RoundedCornerShape(12.dp))
            )
            Spacer(Modifier.height(12.dp))
            Text("Rampas Meza", fontWeight = FontWeight.Bold, fontSize = 22.sp, color = Color.Black)
            Text("Acceso de Empleado", fontSize = 13.sp, color = Color.Gray)
            Spacer(Modifier.height(48.dp))

            MenuBoton(icono = Icons.Default.Inventory2, texto = "Añadir Stock",
                subtexto = "Registrar entradas de material", onClick = onAddStockClick)
            Spacer(Modifier.height(16.dp))
            MenuBoton(icono = Icons.Default.PointOfSale, texto = "Registrar Venta",
                subtexto = "Capturar una venta al cliente", onClick = onRegistrarVentasClick)
        }
    }
}

@Composable
private fun MenuBoton(icono: ImageVector, texto: String, subtexto: String, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().height(72.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFD700)),
        shape = RoundedCornerShape(12.dp),
        elevation = ButtonDefaults.buttonElevation(4.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Icon(icono, contentDescription = null, tint = Color.Black, modifier = Modifier.size(28.dp))
            Spacer(Modifier.width(16.dp))
            Column(horizontalAlignment = Alignment.Start) {
                Text(texto, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.Black)
                Text(subtexto, fontSize = 12.sp, color = Color(0xFF444444))
            }
        }
    }
}
