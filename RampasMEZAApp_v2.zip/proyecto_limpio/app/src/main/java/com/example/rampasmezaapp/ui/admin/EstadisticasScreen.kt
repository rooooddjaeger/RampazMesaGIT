package com.example.rampasmezaapp.ui.admin

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.rampasmezaapp.data.Producto
import com.example.rampasmezaapp.ui.inventario.ViewModelInventarioGlobal
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

data class ProductoVendido(val nombre: String, val totalVendido: Int)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EstadisticasScreen(
    inventarioGlobalViewModel: ViewModelInventarioGlobal,
    onBackClick: () -> Unit
) {
    val estadoInventario by inventarioGlobalViewModel.estadoGlobal.collectAsState()
    val firestore = remember { FirebaseFirestore.getInstance() }
    var productosVendidos by remember { mutableStateOf<List<ProductoVendido>>(emptyList()) }
    var totalVentas by remember { mutableStateOf(0) }
    var cargando by remember { mutableStateOf(true) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        scope.launch {
            try {
                val snap = firestore.collection("ventas").get().await()
                val conteo = mutableMapOf<String, Int>()
                var ventas = 0
                snap.documents.forEach { doc ->
                    ventas++
                    @Suppress("UNCHECKED_CAST")
                    val items = doc.get("items") as? List<Map<String, Any?>> ?: emptyList()
                    items.forEach { item ->
                        val nombre = item["nombre"] as? String ?: return@forEach
                        val cantidad = (item["cantidad"] as? Long)?.toInt() ?: 0
                        conteo[nombre] = (conteo[nombre] ?: 0) + cantidad
                    }
                }
                totalVentas = ventas
                productosVendidos = conteo.entries
                    .map { ProductoVendido(it.key, it.value) }
                    .sortedByDescending { it.totalVendido }
            } catch (_: Exception) {}
            cargando = false
        }
    }

    val productos = estadoInventario.productos
    val stockTotal = productos.sumOf { it.currentStock }
    val productosBajos = productos.filter { it.currentStock in 1..10 }
    val productosCero = productos.filter { it.currentStock == 0 }
    val productoMayorStock = productos.maxByOrNull { it.currentStock }
    val maxVendido = productosVendidos.firstOrNull()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Estadísticas", fontWeight = FontWeight.Bold) },
                navigationIcon = { IconButton(onClick = onBackClick) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        }
    ) { paddingValues ->
        if (cargando) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Color(0xFFFFD700))
            }
            return@Scaffold
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF7F7F7))
                .padding(paddingValues)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item { Spacer(Modifier.height(8.dp)) }

            // Tarjetas de resumen
            item {
                Text("Resumen General", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.Gray)
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatCard(Modifier.weight(1f), "Ventas\nregistradas", "$totalVentas", Color(0xFF1565C0), Color.White)
                    StatCard(Modifier.weight(1f), "Stock\ntotal", "$stockTotal", Color(0xFF2E7D32), Color.White)
                    StatCard(Modifier.weight(1f), "Sin\nstock", "${productosCero.size}", Color(0xFFCC2200), Color.White)
                }
            }

            item {
                Text("Highlights", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.Gray)
                Spacer(Modifier.height(8.dp))
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    productoMayorStock?.let {
                        HighlightCard(
                            icono = { Icon(Icons.Default.TrendingUp, null, tint = Color(0xFF2E7D32), modifier = Modifier.size(22.dp)) },
                            titulo = "Mayor stock actual",
                            valor = "${it.name}: ${it.currentStock} pzas"
                        )
                    }
                    maxVendido?.let {
                        HighlightCard(
                            icono = { Icon(Icons.Default.Star, null, tint = Color(0xFFFFD700), modifier = Modifier.size(22.dp)) },
                            titulo = "Producto más vendido",
                            valor = "${it.nombre}: ${it.totalVendido} pzas"
                        )
                    }
                    if (productosBajos.isNotEmpty()) {
                        HighlightCard(
                            icono = { Icon(Icons.Default.Warning, null, tint = Color(0xFFD49000), modifier = Modifier.size(22.dp)) },
                            titulo = "Productos con stock bajo (≤10)",
                            valor = "${productosBajos.size} productos requieren atención"
                        )
                    }
                }
            }

            if (productosVendidos.isNotEmpty()) {
                item {
                    Text("Top 10 Más Vendidos", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.Gray)
                }
                val top10 = productosVendidos.take(10)
                val maxVal = top10.first().totalVendido.toFloat()
                items(top10.withIndex().toList()) { (index, pv) ->
                    BarraProducto(pos = index + 1, nombre = pv.nombre, cantidad = pv.totalVendido, maximo = maxVal)
                }
            }

            if (productosBajos.isNotEmpty()) {
                item {
                    Text("Productos con Stock Bajo", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color(0xFFD49000))
                }
                items(productosBajos.sortedBy { it.currentStock }) { p ->
                    Card(
                        Modifier.fillMaxWidth(), shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF8E1))
                    ) {
                        Row(
                            Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Warning, null, tint = Color(0xFFD49000), modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(10.dp))
                            Text(p.name, Modifier.weight(1f), fontSize = 13.sp)
                            Text("${p.currentStock} pzas", fontWeight = FontWeight.Bold, color = Color(0xFFD49000), fontSize = 13.sp)
                        }
                    }
                }
            }

            item { Spacer(Modifier.height(16.dp)) }
        }
    }
}

@Composable
private fun StatCard(modifier: Modifier, titulo: String, valor: String, bgColor: Color, textColor: Color) {
    Card(modifier = modifier, shape = RoundedCornerShape(12.dp), colors = CardDefaults.cardColors(containerColor = bgColor)) {
        Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(valor, fontWeight = FontWeight.ExtraBold, fontSize = 26.sp, color = textColor)
            Text(titulo, fontSize = 11.sp, color = textColor.copy(alpha = 0.8f), fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
private fun HighlightCard(icono: @Composable () -> Unit, titulo: String, valor: String) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(1.dp)
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            icono()
            Spacer(Modifier.width(12.dp))
            Column {
                Text(titulo, fontSize = 12.sp, color = Color.Gray)
                Text(valor, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
        }
    }
}

@Composable
private fun BarraProducto(pos: Int, nombre: String, cantidad: Int, maximo: Float) {
    val fraccion = if (maximo > 0f) cantidad / maximo else 0f
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(1.dp)
    ) {
        Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("$pos.", fontWeight = FontWeight.Bold, color = Color(0xFFFFD700), fontSize = 13.sp, modifier = Modifier.width(24.dp))
                Text(nombre, Modifier.weight(1f), fontSize = 13.sp, maxLines = 1)
                Text("$cantidad", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
            Spacer(Modifier.height(5.dp))
            Box(
                Modifier.fillMaxWidth().height(8.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color(0xFFEEEEEE))
            ) {
                Box(
                    Modifier.fillMaxWidth(fraccion).fillMaxHeight()
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color(0xFFFFD700))
                )
            }
        }
    }
}
