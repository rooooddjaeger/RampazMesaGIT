package com.example.rampasmezaapp.ui.admin

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

data class UsuarioUI(
    val uid: String,
    val name: String,
    val email: String,
    val rol: String,
    val activo: Boolean,
    val createdAt: Long
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminUsuarios(onBackClick: () -> Unit) {
    val firestore = remember { FirebaseFirestore.getInstance() }
    val currentUid = remember { FirebaseAuth.getInstance().currentUser?.uid }
    var usuarios by remember { mutableStateOf<List<UsuarioUI>>(emptyList()) }
    var cargando by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var mensaje by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    fun cargarUsuarios() {
        scope.launch {
            cargando = true
            try {
                val snap = firestore.collection("users").get().await()
                usuarios = snap.documents.mapNotNull { doc ->
                    UsuarioUI(
                        uid = doc.id,
                        name = doc.getString("name") ?: "Sin nombre",
                        email = doc.getString("email") ?: "",
                        rol = doc.getString("rol") ?: "usuario",
                        activo = doc.getBoolean("activo") ?: true,
                        createdAt = doc.getLong("createdAt") ?: 0L
                    )
                }.sortedBy { it.name }
            } catch (e: Exception) {
                error = "Error al cargar usuarios: ${e.message}"
            } finally {
                cargando = false
            }
        }
    }

    LaunchedEffect(Unit) { cargarUsuarios() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Administrar Usuarios", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Regresar")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF7F7F7))
                .padding(paddingValues)
        ) {
            when {
                cargando -> {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = Color(0xFFFFD700))
                    }
                }
                error != null -> {
                    Text(error ?: "", modifier = Modifier.padding(24.dp), color = Color.Red)
                }
                else -> {
                    Column(Modifier.fillMaxSize()) {
                        // Resumen
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            val admins = usuarios.count { it.rol == "admin" }
                            val empleados = usuarios.count { it.rol == "usuario" }
                            ResumenChip("Admins: $admins", Color(0xFF1565C0))
                            ResumenChip("Empleados: $empleados", Color(0xFF2E7D32))
                            ResumenChip("Total: ${usuarios.size}", Color(0xFF4A4A4A))
                        }

                        LazyColumn(
                            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            items(usuarios) { usuario ->
                                TarjetaUsuario(
                                    usuario = usuario,
                                    esMismoUsuario = usuario.uid == currentUid,
                                    onCambiarRol = { uid, nuevoRol ->
                                        scope.launch {
                                            try {
                                                firestore.collection("users").document(uid)
                                                    .update("rol", nuevoRol).await()
                                                mensaje = "Rol actualizado correctamente"
                                                cargarUsuarios()
                                            } catch (e: Exception) {
                                                mensaje = "Error: ${e.message}"
                                            }
                                        }
                                    },
                                    onToggleActivo = { uid, activo ->
                                        scope.launch {
                                            try {
                                                firestore.collection("users").document(uid)
                                                    .update("activo", activo).await()
                                                mensaje = if (activo) "Usuario activado" else "Usuario desactivado"
                                                cargarUsuarios()
                                            } catch (e: Exception) {
                                                mensaje = "Error: ${e.message}"
                                            }
                                        }
                                    }
                                )
                            }
                            item { Spacer(Modifier.height(16.dp)) }
                        }
                    }
                }
            }

            mensaje?.let { msg ->
                LaunchedEffect(msg) {
                    kotlinx.coroutines.delay(2500)
                    mensaje = null
                }
                Snackbar(
                    modifier = Modifier.align(Alignment.BottomCenter).padding(16.dp),
                    containerColor = Color(0xFF323232)
                ) {
                    Text(msg, color = Color.White)
                }
            }
        }
    }
}

@Composable
private fun TarjetaUsuario(
    usuario: UsuarioUI,
    esMismoUsuario: Boolean,
    onCambiarRol: (String, String) -> Unit,
    onToggleActivo: (String, Boolean) -> Unit
) {
    var mostrarMenu by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (usuario.activo) Color.White else Color(0xFFF0F0F0)
        ),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Avatar inicial
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .background(
                        if (usuario.rol == "admin") Color(0xFF1565C0) else Color(0xFFFFD700),
                        CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    usuario.name.firstOrNull()?.uppercase() ?: "?",
                    fontWeight = FontWeight.Bold,
                    color = if (usuario.rol == "admin") Color.White else Color.Black,
                    fontSize = 18.sp
                )
            }

            Spacer(Modifier.width(12.dp))

            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(usuario.name, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    if (esMismoUsuario) {
                        Spacer(Modifier.width(6.dp))
                        Text("(tú)", fontSize = 11.sp, color = Color.Gray)
                    }
                }
                Text(usuario.email, fontSize = 12.sp, color = Color.Gray)
                Spacer(Modifier.height(4.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    RolChip(usuario.rol)
                    if (!usuario.activo) {
                        StatusChip("Inactivo", Color(0xFFBDBDBD))
                    }
                }
            }

            if (!esMismoUsuario) {
                Box {
                    IconButton(onClick = { mostrarMenu = true }) {
                        Icon(Icons.Default.MoreVert, "Opciones", tint = Color.Gray)
                    }
                    DropdownMenu(expanded = mostrarMenu, onDismissRequest = { mostrarMenu = false }) {
                        val nuevoRol = if (usuario.rol == "admin") "usuario" else "admin"
                        val textoRol = if (usuario.rol == "admin") "Cambiar a Empleado" else "Cambiar a Admin"
                        DropdownMenuItem(
                            text = { Text(textoRol) },
                            onClick = {
                                mostrarMenu = false
                                onCambiarRol(usuario.uid, nuevoRol)
                            },
                            leadingIcon = { Icon(Icons.Default.SwapHoriz, null) }
                        )
                        DropdownMenuItem(
                            text = { Text(if (usuario.activo) "Desactivar usuario" else "Activar usuario") },
                            onClick = {
                                mostrarMenu = false
                                onToggleActivo(usuario.uid, !usuario.activo)
                            },
                            leadingIcon = {
                                Icon(
                                    if (usuario.activo) Icons.Default.PersonOff else Icons.Default.PersonAdd,
                                    null
                                )
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun RolChip(rol: String) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = if (rol == "admin") Color(0xFF1565C0) else Color(0xFFFFD700)
    ) {
        Text(
            if (rol == "admin") "Admin" else "Empleado",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = if (rol == "admin") Color.White else Color.Black,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp)
        )
    }
}

@Composable
private fun StatusChip(texto: String, color: Color) {
    Surface(shape = RoundedCornerShape(20.dp), color = color) {
        Text(texto, fontSize = 11.sp, color = Color.DarkGray, modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp))
    }
}

@Composable
private fun ResumenChip(texto: String, color: Color) {
    Surface(shape = RoundedCornerShape(20.dp), color = color.copy(alpha = 0.12f)) {
        Text(texto, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = color,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp))
    }
}
