package com.example.rampasmezaapp.ui.ventas

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

data class ItemVentaUI(
    val fecha: String,
    val empleado: String,
    val total: Double?,
    val items: List<Map<String, Any?>>
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistorialVentas(onBackToMainClick: () -> Unit) {
    val firestore = remember { FirebaseFirestore.getInstance() }
    var ventas by remember { mutableStateOf<List<ItemVentaUI>>(emptyList()) }
    var cargando by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        try {
            val snap = firestore.collection("ventas")
                .orderBy("fecha", com.google.firebase.firestore.Query.Direction.DESCENDING)
                .get().await()
            ventas = snap.documents.map { doc ->
                ItemVentaUI(
                    fecha = doc.getString("fecha") ?: "",
                    empleado = doc.getString("empleado") ?: "Desconocido",
                    total = doc.getDouble("total"),
                    items = (doc.get("items") as? List<Map<String, Any?>>) ?: emptyList()
                )
            }
        } catch (e: Exception) {
            error = e.message
        } finally {
            cargando = false
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Historial de Ventas", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBackToMainClick) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Regresar")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF7F7F7))
                .padding(padding)
        ) {
            when {
                cargando -> Box(Modifier.fillMaxSize(), Alignment.Center) {
                    CircularProgressIndicator(color = Color(0xFFFFD700))
                }
                error != null -> Text("Error: $error", modifier = Modifier.padding(24.dp), color = Color.Red)
                ventas.isEmpty() -> Box(Modifier.fillMaxSize(), Alignment.Center) {
                    Text("No hay ventas registradas", color = Color.Gray)
                }
                else -> {
                    Column(Modifier.fillMaxSize()) {
                        // Resumen
                        Surface(color = Color.White) {
                            Row(
                                Modifier.fillMaxWidth().padding(16.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("${ventas.size} venta${if (ventas.size != 1) "s" else ""} registrada${if (ventas.size != 1) "s" else ""}", color = Color.Gray, fontSize = 13.sp)
                            }
                        }
                        LazyColumn(
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            items(ventas.withIndex().toList()) { (index, venta) ->
                                TarjetaVenta(numero = ventas.size - index, venta = venta)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TarjetaVenta(numero: Int, venta: ItemVentaUI) {
    var expandida by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(2.dp),
        onClick = { expandida = !expandida }
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFFFD700)
                ) {
                    Text(
                        "#$numero",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Schedule, null, modifier = Modifier.size(13.dp), tint = Color.Gray)
                        Spacer(Modifier.width(4.dp))
                        Text(venta.fecha, fontSize = 12.sp, color = Color.Gray)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Person, null, modifier = Modifier.size(13.dp), tint = Color(0xFF1565C0))
                        Spacer(Modifier.width(4.dp))
                        Text(venta.empleado, fontSize = 12.sp, color = Color(0xFF1565C0), fontWeight = FontWeight.Medium)
                    }
                }
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = Color(0xFFE8F5E9)
                ) {
                    Text(
                        "${venta.items.size} prod.",
                        fontSize = 11.sp,
                        color = Color(0xFF2E7D32),
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            if (expandida) {
                Spacer(Modifier.height(10.dp))
                Divider(color = Color(0xFFEEEEEE))
                Spacer(Modifier.height(8.dp))
                venta.items.forEach { item ->
                    val nombre = item["nombre"]?.toString() ?: "Producto"
                    val cantidad = item["cantidad"]?.toString() ?: "0"
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 2.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("• $nombre", fontSize = 13.sp, modifier = Modifier.weight(1f))
                        Text("x $cantidad", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1565C0))
                    }
                }
            }
        }
    }
}
