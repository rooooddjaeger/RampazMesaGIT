package com.example.rampasmezaapp.ui.inventario

import android.content.Intent
import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.rampasmezaapp.data.Producto
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReporteInventario(
    inventarioGlobalViewModel: ViewModelInventarioGlobal,
    onBackToMainClick: () -> Unit
) {
    val estado by inventarioGlobalViewModel.estadoGlobal.collectAsState()
    val context = LocalContext.current
    val fecha = remember {
        SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date())
    }

    // Filtros
    var filtro by remember { mutableStateOf("todos") } // "todos" | "bajo" | "sinStock"

    val productosFiltrados = remember(estado.productos, filtro) {
        when (filtro) {
            "bajo" -> estado.productos.filter { it.currentStock in 1..10 }
            "sinStock" -> estado.productos.filter { it.currentStock == 0 }
            else -> estado.productos
        }
    }

    val totalPiezas = estado.productos.sumOf { it.currentStock }
    val sinStock = estado.productos.count { it.currentStock == 0 }
    val stockBajo = estado.productos.count { it.currentStock in 1..10 }

    fun generarTextoReporte(): String {
        val sb = StringBuilder()
        sb.appendLine("====================================")
        sb.appendLine("   REPORTE DE INVENTARIO")
        sb.appendLine("   RAMPAS MEZA")
        sb.appendLine("====================================")
        sb.appendLine("Fecha: $fecha")
        sb.appendLine("Total piezas en stock: $totalPiezas")
        sb.appendLine("Sin stock: $sinStock productos")
        sb.appendLine("Stock bajo (≤10): $stockBajo productos")
        sb.appendLine("------------------------------------")
        sb.appendLine(String.format("%-32s %s", "PRODUCTO", "STOCK"))
        sb.appendLine("------------------------------------")
        estado.productos.sortedBy { it.name }.forEach { p ->
            val alerta = when {
                p.currentStock == 0 -> " ⚠ SIN STOCK"
                p.currentStock <= 10 -> " ⚠ BAJO"
                else -> ""
            }
            sb.appendLine(String.format("%-32s %d%s", p.name.take(32), p.currentStock, alerta))
        }
        sb.appendLine("====================================")
        sb.appendLine("Generado con RampasMEZA App")
        return sb.toString()
    }

    fun compartirReporte() {
        val texto = generarTextoReporte()
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "Reporte de Inventario Rampas Meza - $fecha")
            putExtra(Intent.EXTRA_TEXT, texto)
        }
        context.startActivity(Intent.createChooser(intent, "Compartir reporte"))
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Reporte de Inventario", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBackToMainClick) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Regresar")
                    }
                },
                actions = {
                    IconButton(onClick = { compartirReporte() }) {
                        Icon(Icons.Default.Share, "Compartir", tint = Color(0xFF1565C0))
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF7F7F7))
                .padding(paddingValues)
        ) {
            if (estado.cargando) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = Color(0xFFFFD700))
                }
                return@Column
            }

            // Header con resumen
            Column(
                Modifier
                    .fillMaxWidth()
                    .background(Color.White)
                    .padding(16.dp)
            ) {
                Text("Generado: $fecha", fontSize = 12.sp, color = Color.Gray)
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    ResumenCard(Modifier.weight(1f), "Total piezas", "$totalPiezas", Color(0xFF1565C0))
                    ResumenCard(Modifier.weight(1f), "Sin stock", "$sinStock", Color(0xFFCC2200))
                    ResumenCard(Modifier.weight(1f), "Stock bajo", "$stockBajo", Color(0xFFD49000))
                }
            }

            // Filtros
            Spacer(Modifier.height(8.dp))
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FiltroChip("Todos", filtro == "todos") { filtro = "todos" }
                FiltroChip("Stock bajo", filtro == "bajo") { filtro = "bajo" }
                FiltroChip("Sin stock", filtro == "sinStock") { filtro = "sinStock" }
            }

            Spacer(Modifier.height(8.dp))

            // Lista de productos
            LazyColumn(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                item {
                    Text(
                        "${productosFiltrados.size} producto${if (productosFiltrados.size != 1) "s" else ""}",
                        fontSize = 12.sp, color = Color.Gray,
                        modifier = Modifier.padding(vertical = 4.dp)
                    )
                }
                items(productosFiltrados.sortedBy { it.name }) { producto ->
                    FilaProductoReporte(producto)
                }
                item { Spacer(Modifier.height(16.dp)) }
            }
        }
    }
}

@Composable
private fun ResumenCard(modifier: Modifier, titulo: String, valor: String, color: Color) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.12f))
    ) {
        Column(Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(valor, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp, color = color)
            Text(titulo, fontSize = 11.sp, color = Color.DarkGray)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FiltroChip(label: String, seleccionado: Boolean, onClick: () -> Unit) {
    FilterChip(
        selected = seleccionado,
        onClick = onClick,
        label = { Text(label, fontSize = 12.sp) },
        colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = Color(0xFFFFD700),
            selectedLabelColor = Color.Black
        )
    )
}

@Composable
private fun FilaProductoReporte(producto: Producto) {
    val (bgColor, stockColor, etiqueta) = when {
        producto.currentStock == 0 -> Triple(Color(0xFFFFEBEB), Color(0xFFCC2200), "Sin stock")
        producto.currentStock <= 10 -> Triple(Color(0xFFFFF8E1), Color(0xFFD49000), "Stock bajo")
        else -> Triple(Color.White, Color(0xFF2E7D32), "")
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = bgColor),
        elevation = CardDefaults.cardElevation(1.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(producto.name, fontWeight = FontWeight.Medium, fontSize = 13.sp)
                if (etiqueta.isNotBlank()) {
                    Text(etiqueta, fontSize = 11.sp, color = stockColor, fontWeight = FontWeight.Bold)
                }
            }
            Text(
                "${producto.currentStock} pzas",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = stockColor
            )
        }
    }
}
