package com.example.rampasmezaapp.ui.admin

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.rampasmezaapp.R
import com.example.rampasmezaapp.ui.inventario.ViewModelInventarioGlobal

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PanelAdmin(
    nombreAdmin: String,
    inventarioGlobalViewModel: ViewModelInventarioGlobal,
    onLogoutClick: () -> Unit,
    onAddStockClick: () -> Unit,
    onRegistrarVentasClick: () -> Unit,
    onHistorialVentasClick: () -> Unit,
    onReporteInventarioClick: () -> Unit,
    onAdminUsuariosClick: () -> Unit,
    onEstadisticasClick: () -> Unit
) {
    val estadoInventario by inventarioGlobalViewModel.estadoGlobal.collectAsState()
    val productosStockBajo = remember(estadoInventario.productos) {
        estadoInventario.productos.count { it.currentStock in 1..10 }
    }
    val productosSinStock = remember(estadoInventario.productos) {
        estadoInventario.productos.count { it.currentStock == 0 }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Panel Administrador", fontWeight = FontWeight.Bold, color = Color.Black, fontSize = 18.sp)
                        if (nombreAdmin.isNotBlank())
                            Text("Bienvenido, $nombreAdmin", fontSize = 12.sp, color = Color.Gray)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White),
                actions = {
                    IconButton(onClick = onLogoutClick) {
                        Icon(Icons.AutoMirrored.Filled.ExitToApp, "Cerrar sesión", tint = Color.Black)
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF7F7F7))
                .padding(paddingValues)
                .padding(horizontal = 20.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(16.dp))

            Image(
                painter = painterResource(id = R.drawable.logo_rampas_meza),
                contentDescription = "Logo",
                modifier = Modifier.size(110.dp).clip(RoundedCornerShape(12.dp))
            )

            Spacer(Modifier.height(12.dp))

            // Tarjetas de resumen rápido
            if (!estadoInventario.cargando) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    TarjetaResumen(
                        modifier = Modifier.weight(1f),
                        titulo = "Stock bajo",
                        valor = "$productosStockBajo",
                        color = Color(0xFFFFF3CD),
                        iconColor = Color(0xFFD49000)
                    )
                    TarjetaResumen(
                        modifier = Modifier.weight(1f),
                        titulo = "Sin stock",
                        valor = "$productosSinStock",
                        color = Color(0xFFFFE0E0),
                        iconColor = Color(0xFFCC2200)
                    )
                    TarjetaResumen(
                        modifier = Modifier.weight(1f),
                        titulo = "Total prod.",
                        valor = "${estadoInventario.productos.size}",
                        color = Color(0xFFE8F5E9),
                        iconColor = Color(0xFF2E7D32)
                    )
                }
            }

            Spacer(Modifier.height(20.dp))

            // Sección Operaciones
            SectionLabel("Operaciones")
            Spacer(Modifier.height(8.dp))
            AdminBoton(icono = Icons.Default.Inventory2, texto = "Añadir Stock",
                subtexto = "Registrar entradas de material", color = Color(0xFFFFD700), onClick = onAddStockClick)
            Spacer(Modifier.height(12.dp))
            AdminBoton(icono = Icons.Default.PointOfSale, texto = "Registrar Venta",
                subtexto = "Capturar venta al cliente", color = Color(0xFFFFD700), onClick = onRegistrarVentasClick)

            Spacer(Modifier.height(20.dp))

            // Sección Reportes
            SectionLabel("Reportes y Análisis")
            Spacer(Modifier.height(8.dp))
            AdminBoton(icono = Icons.AutoMirrored.Filled.List, texto = "Historial de Ventas",
                subtexto = "Ver todas las ventas registradas", color = Color(0xFF1565C0), textoColor = Color.White, onClick = onHistorialVentasClick)
            Spacer(Modifier.height(12.dp))
            AdminBoton(icono = Icons.Default.Assessment, texto = "Reporte de Inventario",
                subtexto = "Exportar inventario actual en PDF", color = Color(0xFF1565C0), textoColor = Color.White, onClick = onReporteInventarioClick)
            Spacer(Modifier.height(12.dp))
            AdminBoton(icono = Icons.Default.BarChart, texto = "Estadísticas",
                subtexto = "Productos más vendidos y más", color = Color(0xFF1565C0), textoColor = Color.White, onClick = onEstadisticasClick)

            Spacer(Modifier.height(20.dp))

            // Sección Admin
            SectionLabel("Administración")
            Spacer(Modifier.height(8.dp))
            AdminBoton(icono = Icons.Default.ManageAccounts, texto = "Administrar Usuarios",
                subtexto = "Ver, editar y cambiar roles", color = Color(0xFF4A4A4A), textoColor = Color.White, onClick = onAdminUsuariosClick)

            Spacer(Modifier.height(32.dp))
        }
    }
}

@Composable
private fun SectionLabel(texto: String) {
    Text(
        texto,
        fontWeight = FontWeight.Bold,
        fontSize = 13.sp,
        color = Color.Gray,
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
private fun TarjetaResumen(
    modifier: Modifier = Modifier,
    titulo: String,
    valor: String,
    color: Color,
    iconColor: Color
) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = color), shape = RoundedCornerShape(12.dp)) {
        Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(valor, fontWeight = FontWeight.ExtraBold, fontSize = 24.sp, color = iconColor)
            Text(titulo, fontSize = 11.sp, color = Color.DarkGray, fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
private fun AdminBoton(
    icono: ImageVector,
    texto: String,
    subtexto: String,
    color: Color,
    textoColor: Color = Color.Black,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().height(68.dp),
        colors = ButtonDefaults.buttonColors(containerColor = color),
        shape = RoundedCornerShape(12.dp),
        elevation = ButtonDefaults.buttonElevation(3.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Icon(icono, null, tint = textoColor, modifier = Modifier.size(26.dp))
            Spacer(Modifier.width(14.dp))
            Column(horizontalAlignment = Alignment.Start) {
                Text(texto, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = textoColor)
                Text(subtexto, fontSize = 11.sp, color = if (textoColor == Color.Black) Color(0xFF444444) else textoColor.copy(alpha = 0.75f))
            }
        }
    }
}
